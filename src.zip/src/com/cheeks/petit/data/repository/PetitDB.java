package com.cheeks.petit.data.repository;

import java.util.ArrayList;
import java.util.List;

import com.cheeks.petit.data.dto.Admin;
import com.cheeks.petit.data.dto.Officer;
import com.cheeks.petit.data.dto.Petition;
import com.cheeks.petit.data.dto.User;

public class PetitDB {

    private static PetitDB instance;

    private List<User> users = new ArrayList<>();
    private List<Admin> admins = new ArrayList<>();
    private List<Officer> officers = new ArrayList<>();
    private List<Petition> petitions = new ArrayList<>();

    private PetitDB() {}

    public static PetitDB getInstance() {
        if (instance == null) {
            instance = new PetitDB();
        }
        return instance;
    }

    // Getters for lists
    public List<User> getUsers() {
        return users;
    }

    public List<Admin> getAdmins() {
        return admins;
    }

    public List<Officer> getOfficers() {
        return officers;
    }

    public List<Petition> getPetitions() {
        return petitions;
    }

    // User Operations
    public void addUser(User user) {
        users.add(user);
    }

    public void updateUser(User updatedUser) {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getUserId().equals(updatedUser.getUserId())) {
                users.set(i, updatedUser);
                break;
            }
        }
    }

    // Admin Operations
    public void addAdmin(Admin admin) {
        admins.add(admin);
    }

    // Officer Operations
    public void addOfficer(Officer officer) {
        officers.add(officer);
    }

    public void deleteOfficer(String officerId) {
        officers.removeIf(o -> o.getOfficerId().equals(officerId));
    }

    // Petition Operations
    public void addPetition(Petition petition) {
        petitions.add(petition);
    }

}