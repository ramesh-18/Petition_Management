package com.cheeks.petit.data.repository;

import com.cheeks.petit.data.dto.Admin;

public class DataInitializer {

    public static void init() {

        Admin admin = new Admin();
        admin.setAdminId("A1");
        admin.setEmail("admin@gmail.com");
        admin.setPassword("admin123");

        PetitDB.getInstance().addAdmin(admin);
    }
}