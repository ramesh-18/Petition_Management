package com.cheeks.petit.data.dto;

import com.cheeks.petit.data.enums.Department;
import com.cheeks.petit.data.enums.Priority;
import com.cheeks.petit.data.enums.Status;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Petition {
    private String petitionId;
    private String userId;
    private String title;
    private String description;
    private Status status;
    private Priority priority;
    private Department department;  //enum
    private LocalDate eventDate;
    private LocalDateTime submittedAt;
    private LocalDateTime updatedAt;
    private String location;
    public String getPetitionId() {
        return petitionId;
    }
    public void setPetitionId(String petitionId) {
        this.petitionId = petitionId;
    }
    public String getUserId() {
        return userId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public Department getDepartment() {
        return department;
    }
    public void setDepartment(Department department) {
        this.department = department;
    }
    public Status getStatus() {
        return status;
    }
    public void setStatus(Status status) {
        this.status = status;
    }
    public Priority getPriority() {
        return priority;
    }
    public void setPriority(Priority priority) {
        this.priority = priority;
    }
    public LocalDate getEventDate() {
        return eventDate;
    }
    public void setEventDate(LocalDate eventDate) {
        this.eventDate = eventDate;
    }
    public LocalDateTime getSubmittedAt() {
        return submittedAt;
    }
    public void setSubmittedAt(LocalDateTime submittedAt) {
        this.submittedAt = submittedAt;
    }
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    public String getLocation() {
        return location;
    }
    public void setLocation(String location) {
        this.location = location;
    }
}

