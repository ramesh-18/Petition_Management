package com.cheeks.petit.data.enums;

public enum Status {
    OPEN,
    IN_PROGRESS,
    COMPLETED,
    REJECTED
}
