package com.cheeks.petit.data.enums;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH
}
