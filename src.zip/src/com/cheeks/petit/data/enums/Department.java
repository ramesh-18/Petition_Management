package com.cheeks.petit.data.enums;

public enum Department {
    POLICE,
    ENGINEERING,
    REVENUE,
    HEALTH,
    PENSION,
    ADMINISTRATION
}
