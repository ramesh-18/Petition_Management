package com.cheeks.petit.features.petition.create;

import java.time.LocalDate;
import java.util.Scanner;

import com.cheeks.petit.data.dto.Petition;
import com.cheeks.petit.data.enums.Department;
import com.cheeks.petit.data.enums.Priority;

public class PetitionCreateView {

    private PetitionCreateModel model = new PetitionCreateModel();

    public void show(String userId) {

        Scanner sc = new Scanner(System.in);

        System.out.println("=== CREATE PETITION ===");

        Petition petition = new Petition();

        petition.setUserId(userId);

        System.out.print("Title: ");
        petition.setTitle(sc.nextLine());

        System.out.print("Description: ");
        petition.setDescription(sc.nextLine());

        System.out.print("Location: ");
        petition.setLocation(sc.nextLine());


        System.out.print("Event Date (YYYY-MM-DD): ");
        petition.setEventDate(LocalDate.parse(sc.nextLine()));


        System.out.println("Select Department:");
        Department[] departments = Department.values();

        for (int i = 0; i < departments.length; i++) {
            System.out.println((i + 1) + ". " + departments[i]);
        }

        System.out.print("Enter choice: ");
        int deptChoice = sc.nextInt();
        sc.nextLine();


        System.out.println("Select Priority:");
        Priority[] priorities = Priority.values();

        for (int i = 0; i < priorities.length; i++) {
            System.out.println((i + 1) + ". " + priorities[i]);
        }

        System.out.print("Enter choice: ");
        int prChoice = sc.nextInt();
        sc.nextLine();

        petition.setDepartment(departments[deptChoice - 1]);
        petition.setPriority(priorities[prChoice - 1]);

        String result = model.createPetition(petition);

        System.out.println(result);
    }
}