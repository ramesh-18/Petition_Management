package com.cheeks.petit.features.petition.create;

import java.time.LocalDateTime;

import com.cheeks.petit.data.dto.Petition;
import com.cheeks.petit.data.enums.Status;
import com.cheeks.petit.data.repository.PetitDB;

class PetitionCreateModel {

    String createPetition(Petition petition) {


        if (petition.getTitle() == null || petition.getTitle().isEmpty()) {
            return "Title cannot be empty";
        }

        if (petition.getDepartment() == null) {
            return "Department must be selected";
        }


        petition.setPetitionId("P" + (PetitDB.getInstance().getPetitions().size() + 1));


        petition.setStatus(Status.OPEN);
        petition.setSubmittedAt(LocalDateTime.now());
        petition.setUpdatedAt(LocalDateTime.now());


        PetitDB.getInstance().addPetition(petition);

        return "Petition created successfully";
    }
}