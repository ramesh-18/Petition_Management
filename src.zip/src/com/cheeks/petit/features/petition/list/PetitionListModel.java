package com.cheeks.petit.features.petition.list;

import com.cheeks.petit.data.dto.Petition;
import com.cheeks.petit.data.repository.PetitDB;

import java.util.ArrayList;
import java.util.List;

class PetitionListModel {
    List<Petition> getPetitionsByUserId(String userId) {
        List<Petition> userPetitions = new ArrayList<>();
        for (Petition p : PetitDB.getInstance().getPetitions()) {
            if (p.getUserId().equals(userId)) {
                userPetitions.add(p);
            }
        }
        return userPetitions;
    }
}
