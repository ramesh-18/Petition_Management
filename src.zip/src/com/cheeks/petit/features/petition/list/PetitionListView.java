package com.cheeks.petit.features.petition.list;

import com.cheeks.petit.data.dto.Petition;
import com.cheeks.petit.features.petition.detail.PetitionDetailView;

import java.util.List;
import java.util.Scanner;

public class PetitionListView {
    private PetitionListModel model = new PetitionListModel();

    public void show(String userId) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            List<Petition> petitions = model.getPetitionsByUserId(userId);
            System.out.println("\n=== MY PETITIONS ===");
            if (petitions.isEmpty()) {
                System.out.println("No petitions found.");
            } else {
                for (int i = 0; i < petitions.size(); i++) {
                    Petition p = petitions.get(i);
                    System.out.println((i + 1) + ". " + p.getTitle() + " [" + p.getStatus() + "]");
                }
            }
            System.out.println("0. Back");
            System.out.print("Select a petition for details (or 0): ");
            int choice = sc.nextInt();
            sc.nextLine();

            if (choice == 0) break;
            if (choice > 0 && choice <= petitions.size()) {
                new PetitionDetailView().show(petitions.get(choice - 1).getPetitionId());
            } else {
                System.out.println("Invalid choice.");
            }
        }
    }
}
