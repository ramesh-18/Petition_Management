package com.cheeks.petit.features.petition.detail;

import com.cheeks.petit.data.dto.Petition;

public class PetitionDetailView {
    private PetitionDetailModel model = new PetitionDetailModel();

    public void show(String petitionId) {
        Petition p = model.getPetitionById(petitionId);
        if (p == null) {
            System.out.println("Petition not found.");
            return;
        }

        System.out.println("\n=== PETITION DETAILS ===");
        System.out.println("ID: " + p.getPetitionId());
        System.out.println("Title: " + p.getTitle());
        System.out.println("Description: " + p.getDescription());
        System.out.println("Status: " + p.getStatus());
        System.out.println("Priority: " + p.getPriority());
        System.out.println("Department: " + p.getDepartment());
        System.out.println("Location: " + p.getLocation());
        System.out.println("Event Date: " + p.getEventDate());
        System.out.println("Submitted At: " + p.getSubmittedAt());
        System.out.println("Updated At: " + p.getUpdatedAt());
        System.out.println("=========================");
    }
}
