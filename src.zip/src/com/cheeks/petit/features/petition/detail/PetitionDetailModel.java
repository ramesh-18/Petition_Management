package com.cheeks.petit.features.petition.detail;

import com.cheeks.petit.data.dto.Petition;
import com.cheeks.petit.data.repository.PetitDB;

class PetitionDetailModel {
    Petition getPetitionById(String petitionId) {
        for (Petition p : PetitDB.getInstance().getPetitions()) {
            if (p.getPetitionId().equals(petitionId)) {
                return p;
            }
        }
        return null;
    }
}
