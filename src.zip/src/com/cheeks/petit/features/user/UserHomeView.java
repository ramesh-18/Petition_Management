package com.cheeks.petit.features.user;

import com.cheeks.petit.features.petition.create.PetitionCreateView;
import com.cheeks.petit.features.petition.list.PetitionListView;
import com.cheeks.petit.features.user.profile.UserProfileView;

import java.util.Scanner;

public class UserHomeView {
    public void show(String userId) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== USER HOME ===");
            System.out.println("1. Create Petition");
            System.out.println("2. My Petitions");
            System.out.println("3. My Profile");
            System.out.println("0. Logout");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            if (choice == 0) break;

            switch (choice) {
                case 1:
                    new PetitionCreateView().show(userId);
                    break;
                case 2:
                    new PetitionListView().show(userId);
                    break;
                case 3:
                    new UserProfileView().show(userId);
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}