package com.cheeks.petit.features.user.signin;

import java.util.Scanner;
import com.cheeks.petit.data.dto.User;
import com.cheeks.petit.features.user.UserHomeView;

public class UserSignInView {
    private UserSignInModel model = new UserSignInModel();

    public void show() {
        Scanner sc = new Scanner(System.in);
        System.out.println("\n=== USER LOGIN ===");
        System.out.print("Email: ");
        String email = sc.nextLine();
        System.out.print("Password: ");
        String password = sc.nextLine();

        User user = model.login(email, password);
        if (user != null) {
            System.out.println("Login Successful!");
            new UserHomeView().show(user.getUserId());
        } else {
            System.out.println("Invalid credentials");
        }
    }
}