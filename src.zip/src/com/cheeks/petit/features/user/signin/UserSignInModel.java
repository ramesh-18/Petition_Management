package com.cheeks.petit.features.user.signin;

import com.cheeks.petit.data.dto.User;
import com.cheeks.petit.data.repository.PetitDB;

 class UserSignInModel {
    User login(String email, String password) {

        for (User user : PetitDB.getInstance().getUsers()) {
            if (user.getEmail().equals(email) &&
                    user.getPassword().equals(password)) {

                return user;
            }
        }

        return null;
    }
}
