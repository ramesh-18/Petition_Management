package com.cheeks.petit.features.user;

import com.cheeks.petit.features.user.signin.UserSignInView;
import com.cheeks.petit.features.user.signup.UserSignUpView;

import java.util.Scanner;

public class UserAccessView {
    public void show() {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n--- USER ACCESS ---");
            System.out.println("1. Signup");
            System.out.println("2. Login");
            System.out.println("0. Back");
            System.out.print("Enter choice: ");
            int userChoice = sc.nextInt();
            sc.nextLine();

            if (userChoice == 0) break;

            switch (userChoice) {
                case 1:
                    new UserSignUpView().show();
                    break;
                case 2:
                    new UserSignInView().show();
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
