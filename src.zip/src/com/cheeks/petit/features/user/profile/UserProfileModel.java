package com.cheeks.petit.features.user.profile;

import com.cheeks.petit.data.dto.User;
import com.cheeks.petit.data.repository.PetitDB;

class UserProfileModel {
    User getUserById(String userId) {
        for (User u : PetitDB.getInstance().getUsers()) {
            if (u.getUserId().equals(userId)) {
                return u;
            }
        }
        return null;
    }

    String updateUser(User updatedUser) {
        PetitDB.getInstance().updateUser(updatedUser);
        return "Profile updated successfully.";
    }
}
