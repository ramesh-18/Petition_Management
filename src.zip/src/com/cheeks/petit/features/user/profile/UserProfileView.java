package com.cheeks.petit.features.user.profile;

import com.cheeks.petit.data.dto.User;
import java.util.Scanner;

public class UserProfileView {
    private UserProfileModel model = new UserProfileModel();

    public void show(String userId) {
        Scanner sc = new Scanner(System.in);
        User user = model.getUserById(userId);
        if (user == null) {
            System.out.println("User not found.");
            return;
        }

        while (true) {
            System.out.println("\n=== MY PROFILE ===");
            System.out.println("1. Name: " + user.getName());
            System.out.println("2. Email: " + user.getEmail());
            System.out.println("3. Phone: " + user.getPhoneNumber());
            System.out.println("4. Gender: " + user.getGender());
            System.out.println("5. Address: " + user.getAddress());
            System.out.println("0. Back");
            System.out.print("Select field to edit (or 0): ");
            int choice = sc.nextInt();
            sc.nextLine();

            if (choice == 0) break;

            switch (choice) {
                case 1:
                    System.out.print("New Name: ");
                    user.setName(sc.nextLine());
                    break;
                case 2:
                    System.out.print("New Email: ");
                    user.setEmail(sc.nextLine());
                    break;
                case 3:
                    System.out.print("New Phone: ");
                    user.setPhoneNumber(sc.nextLine());
                    break;
                case 4:
                    System.out.print("New Gender: ");
                    user.setGender(sc.nextLine());
                    break;
                case 5:
                    System.out.print("New Address: ");
                    user.setAddress(sc.nextLine());
                    break;
                default:
                    System.out.println("Invalid choice.");
                    continue;
            }
            String result = model.updateUser(user);
            System.out.println(result);
        }
    }
}
