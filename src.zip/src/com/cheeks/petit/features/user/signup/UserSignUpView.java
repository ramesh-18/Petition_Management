package com.cheeks.petit.features.user.signup;

import java.util.Scanner;

import com.cheeks.petit.data.dto.User;


public class UserSignUpView {

    private UserSignUpModel model = new UserSignUpModel();

    public void show() {

        Scanner sc = new Scanner(System.in);

        System.out.println("=== USER SIGNUP ===");

        User user = new User();

        System.out.print("Name: ");
        user.setName(sc.nextLine());

        System.out.print("Email: ");
        user.setEmail(sc.nextLine());

        System.out.print("Password: ");
        user.setPassword(sc.nextLine());

        System.out.print("Phone: ");
        user.setPhoneNumber(sc.nextLine());

        System.out.print("Gender: ");
        user.setGender(sc.nextLine());

        System.out.print("Address: ");
        user.setAddress(sc.nextLine());
        String result = model.register(user);

        System.out.println(result);
    }
}