package com.cheeks.petit.features.user.signup;

import com.cheeks.petit.data.dto.User;
import com.cheeks.petit.data.repository.PetitDB;

class UserSignUpModel {

    String register(User user) {
        if (user.getName() == null || user.getName().trim().isEmpty()) {
            return "Name cannot be empty";
        }

        if (user.getEmail() == null || !user.getEmail().matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            return "Invalid email format";
        }

        if (user.getPassword() == null || user.getPassword().length() < 6) {
            return "Password must be at least 6 characters";
        }

        if (user.getPhoneNumber() == null || !user.getPhoneNumber().matches("\\d{10}")) {
            return "Phone number must be exactly 10 digits";
        }

        if (user.getAddress() == null || user.getAddress().trim().isEmpty()) {
            return "Address cannot be empty";
        }

        for (User u : PetitDB.getInstance().getUsers()) {
            if (u.getEmail().equalsIgnoreCase(user.getEmail())) {
                return "A user with this email already exists";
            }
        }

        user.setUserId("U" + (PetitDB.getInstance().getUsers().size() + 1));
        PetitDB.getInstance().addUser(user);

        return "Signup successful";
    }
}