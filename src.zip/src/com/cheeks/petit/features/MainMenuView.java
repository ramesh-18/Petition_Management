package com.cheeks.petit.features;

import com.cheeks.petit.features.admin.signin.AdminSignInView;
import com.cheeks.petit.features.officer.signin.OfficerSignInView;
import com.cheeks.petit.features.user.UserAccessView;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MainMenuView {
    public void show() {
        Scanner sc = new Scanner(System.in);
        while (true) {
            try {
                System.out.println("\n=== PETITION MANAGEMENT SYSTEM ===");
                System.out.println("1. User");
                System.out.println("2. Admin");
                System.out.println("3. Officer");
                System.out.println("4. Exit");

                System.out.print("Enter choice: ");
                int choice = sc.nextInt();
                sc.nextLine(); // clear buffer

                switch (choice) {
                    case 1:
                        new UserAccessView().show();
                        break;
                    case 2:
                        new AdminSignInView().show();
                        break;
                    case 3:
                        new OfficerSignInView().show();
                        break;
                    case 4:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                sc.nextLine(); // clear buffer
            }
        }
    }
}