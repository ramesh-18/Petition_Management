package com.cheeks.petit.features.officer.signin;

import java.util.Scanner;
import com.cheeks.petit.data.dto.Officer;
import com.cheeks.petit.features.officer.officerpetition.OfficerPetitionView;

public class OfficerSignInView {
    private OfficerSignInModel model = new OfficerSignInModel();

    public void show() {
        Scanner sc = new Scanner(System.in);
        System.out.println("\n=== OFFICER LOGIN ===");
        System.out.print("Email: ");
        String email = sc.nextLine();
        System.out.print("Password: ");
        String password = sc.nextLine();

        Officer officer = model.login(email, password);
        if (officer != null) {
            System.out.println("Officer Login Successful!");
            new OfficerPetitionView().show(officer);
        } else {
            System.out.println("Invalid credentials");
        }
    }
}