package com.cheeks.petit.features.officer.signin;

import com.cheeks.petit.data.dto.Officer;
import com.cheeks.petit.data.repository.PetitDB;

class OfficerSignInModel {

    Officer login(String email, String password) {

        for (Officer officer : PetitDB.getInstance().getOfficers()) {
            if (officer.getEmail().equals(email) &&
                    officer.getPassword().equals(password)) {

                return officer;
            }
        }

        return null;
    }
}