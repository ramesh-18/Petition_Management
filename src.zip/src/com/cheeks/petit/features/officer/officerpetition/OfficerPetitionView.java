package com.cheeks.petit.features.officer.officerpetition;

import java.util.List;
import java.util.Scanner;

import com.cheeks.petit.data.dto.Officer;
import com.cheeks.petit.data.dto.Petition;
import com.cheeks.petit.data.enums.Status;
import com.cheeks.petit.features.petition.detail.PetitionDetailView;

public class OfficerPetitionView {

    private OfficerPetitionModel model = new OfficerPetitionModel();

    public void show(Officer officer) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== OFFICER DASHBOARD (" + officer.getDepartment() + ") ===");
            List<Petition> list = model.getPetitionsByDepartment(officer);

            if (list.isEmpty()) {
                System.out.println("No petitions found for your department.");
                System.out.println("0. Logout");
            } else {
                for (int i = 0; i < list.size(); i++) {
                    Petition p = list.get(i);
                    System.out.println((i + 1) + ". " + p.getTitle() +
                            " | Status: " + p.getStatus() +
                            " | Priority: " + p.getPriority());
                }
                System.out.println("0. Logout");
            }

            System.out.print("Select petition to manage (or 0): ");
            int choice = sc.nextInt();
            sc.nextLine();

            if (choice == 0) break;

            if (choice > 0 && choice <= list.size()) {
                managePetition(list.get(choice - 1));
            } else {
                System.out.println("Invalid choice.");
            }
        }
    }

    private void managePetition(Petition petition) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n--- MANAGE PETITION: " + petition.getPetitionId() + " ---");
            System.out.println("1. View Full Details");
            System.out.println("2. Update Status");
            System.out.println("0. Back");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            if (choice == 0) break;

            switch (choice) {
                case 1:
                    new PetitionDetailView().show(petition.getPetitionId());
                    break;
                case 2:
                    updateStatusMenu(petition);
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private void updateStatusMenu(Petition petition) {
        Scanner sc = new Scanner(System.in);
        System.out.println("\nSelect new status:");
        Status[] statuses = Status.values();

        for (int i = 0; i < statuses.length; i++) {
            System.out.println((i + 1) + ". " + statuses[i]);
        }
        System.out.println("0. Cancel");
        System.out.print("Enter choice: ");
        int statusChoice = sc.nextInt();
        sc.nextLine();

        if (statusChoice == 0) return;

        if (statusChoice > 0 && statusChoice <= statuses.length) {
            String result = model.updateStatus(
                    petition.getPetitionId(),
                    statuses[statusChoice - 1]
            );
            System.out.println(result);
        } else {
            System.out.println("Invalid status choice.");
        }
    }
}