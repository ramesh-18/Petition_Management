package com.cheeks.petit.features.officer.officerpetition;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.cheeks.petit.data.dto.Officer;
import com.cheeks.petit.data.dto.Petition;
import com.cheeks.petit.data.enums.Status;
import com.cheeks.petit.data.repository.PetitDB;

class OfficerPetitionModel {


    List<Petition> getPetitionsByDepartment(Officer officer) {

        List<Petition> result = new ArrayList<>();

        for (Petition p : PetitDB.getInstance().getPetitions()) {
            if (p.getDepartment() == officer.getDepartment()) {
                result.add(p);
            }
        }

        return result;
    }


    String updateStatus(String petitionId, Status status) {

        for (Petition p : PetitDB.getInstance().getPetitions()) {
            if (p.getPetitionId().equals(petitionId)) {

                p.setStatus(status);
                p.setUpdatedAt(LocalDateTime.now());

                return "Status updated successfully";
            }
        }

        return "Petition not found";
    }
}