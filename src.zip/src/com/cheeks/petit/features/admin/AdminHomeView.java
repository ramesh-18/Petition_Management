package com.cheeks.petit.features.admin;

import com.cheeks.petit.features.admin.manageOfficer.ManageOfficerView;
import com.cheeks.petit.data.dto.Petition;
import com.cheeks.petit.data.repository.PetitDB;
import com.cheeks.petit.features.petition.detail.PetitionDetailView;

import java.util.Scanner;

public class AdminHomeView {
    public void show() {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== ADMIN DASHBOARD ===");
            System.out.println("1. Manage Officers");
            System.out.println("2. View All Petitions");
            System.out.println("0. Logout");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            if (choice == 0) break;

            switch (choice) {
                case 1:
                    new ManageOfficerView().show();
                    break;
                case 2:
                    viewAllPetitions();
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private void viewAllPetitions() {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== ALL SYSTEM PETITIONS ===");
            if (PetitDB.getInstance().getPetitions().isEmpty()) {
                System.out.println("No petitions in the system.");
                break;
            }

            for (int i = 0; i < PetitDB.getInstance().getPetitions().size(); i++) {
                Petition p = PetitDB.getInstance().getPetitions().get(i);
                System.out.println((i + 1) + ". [" + p.getPetitionId() + "] " + p.getTitle() + " | Dept: " + p.getDepartment() + " | Status: " + p.getStatus());
            }
            System.out.println("0. Back");
            System.out.print("Select petition for details (or 0): ");
            int choice = sc.nextInt();
            sc.nextLine();

            if (choice == 0) break;
            if (choice > 0 && choice <= PetitDB.getInstance().getPetitions().size()) {
                new PetitionDetailView().show(PetitDB.getInstance().getPetitions().get(choice - 1).getPetitionId());
            } else {
                System.out.println("Invalid choice.");
            }
        }
    }
}