package com.cheeks.petit.features.admin.manageOfficer;

import java.util.List;
import java.util.Scanner;

import com.cheeks.petit.data.dto.Officer;
import com.cheeks.petit.data.enums.Department;

public class ManageOfficerView {

    private ManageOfficerModel model = new ManageOfficerModel();

    public void show() {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== MANAGE OFFICERS ===");
            System.out.println("1. List All Officers");
            System.out.println("2. Add New Officer");
            System.out.println("3. Delete Officer");
            System.out.println("0. Back");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            if (choice == 0) break;

            switch (choice) {
                case 1:
                    listOfficers();
                    break;
                case 2:
                    addOfficer();
                    break;
                case 3:
                    deleteOfficer();
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private void listOfficers() {
        List<Officer> officers = model.getAllOfficers();
        System.out.println("\n--- OFFICER LIST ---");
        if (officers.isEmpty()) {
            System.out.println("No officers found.");
        } else {
            for (Officer o : officers) {
                System.out.println("ID: " + o.getOfficerId() + " | Name: " + o.getName() + " | Dept: " + o.getDepartment() + " | Email: " + o.getEmail());
            }
        }
    }

    private void addOfficer() {
        Scanner sc = new Scanner(System.in);
        System.out.println("\n--- ADD NEW OFFICER ---");
        Officer officer = new Officer();

        System.out.print("Name: ");
        officer.setName(sc.nextLine());

        System.out.print("Email: ");
        officer.setEmail(sc.nextLine());

        System.out.print("Password: ");
        officer.setPassword(sc.nextLine());

        System.out.print("Phone: ");
        officer.setPhoneNumber(sc.nextLine());

        System.out.println("Select Department:");
        Department[] departments = Department.values();
        for (int i = 0; i < departments.length; i++) {
            System.out.println((i + 1) + ". " + departments[i]);
        }

        System.out.print("Enter choice: ");
        int choice = sc.nextInt();
        sc.nextLine();

        if (choice > 0 && choice <= departments.length) {
            officer.setDepartment(departments[choice - 1]);
            String result = model.createOfficer(officer);
            System.out.println(result);
        } else {
            System.out.println("Invalid department selection.");
        }
    }

    private void deleteOfficer() {
        Scanner sc = new Scanner(System.in);
        System.out.print("\nEnter Officer ID to delete: ");
        String id = sc.nextLine();
        String result = model.deleteOfficer(id);
        System.out.println(result);
    }
}