package com.cheeks.petit.features.admin.manageOfficer;

import com.cheeks.petit.data.dto.Officer;
import com.cheeks.petit.data.repository.PetitDB;
import java.util.List;

class ManageOfficerModel {

    List<Officer> getAllOfficers() {
        return PetitDB.getInstance().getOfficers();
    }

    String createOfficer(Officer officer) {
        if (officer.getName() == null || officer.getName().trim().isEmpty()) {
            return "Name cannot be empty";
        }

        if (officer.getEmail() == null || !officer.getEmail().matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            return "Invalid email format";
        }

        if (officer.getPassword() == null || officer.getPassword().length() < 6) {
            return "Password must be at least 6 characters";
        }

        for (Officer o : PetitDB.getInstance().getOfficers()) {
            if (o.getEmail().equalsIgnoreCase(officer.getEmail())) {
                return "An officer with this email already exists";
            }
        }
        officer.setOfficerId("O" + (PetitDB.getInstance().getOfficers().size() + 1));

        PetitDB.getInstance().addOfficer(officer);

        return "Officer created successfully";
    }

    String deleteOfficer(String officerId) {
        PetitDB.getInstance().deleteOfficer(officerId);
        return "Officer deleted successfully";
    }
}