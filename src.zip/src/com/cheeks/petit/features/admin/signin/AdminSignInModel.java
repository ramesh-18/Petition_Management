package com.cheeks.petit.features.admin.signin;

import com.cheeks.petit.data.dto.Admin;
import com.cheeks.petit.data.repository.PetitDB;

class AdminSignInModel {

    Admin login(String email, String password) {

        for (Admin admin : PetitDB.getInstance().getAdmins()) {
            if (admin.getEmail().equals(email) &&
                    admin.getPassword().equals(password)) {

                return admin;
            }
        }

        return null;
    }
}