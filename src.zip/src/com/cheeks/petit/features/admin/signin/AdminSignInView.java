package com.cheeks.petit.features.admin.signin;

import java.util.Scanner;
import com.cheeks.petit.data.dto.Admin;
import com.cheeks.petit.features.admin.AdminHomeView;

public class AdminSignInView {
    private AdminSignInModel model = new AdminSignInModel();

    public void show() {
        Scanner sc = new Scanner(System.in);
        System.out.println("\n=== ADMIN LOGIN ===");
        System.out.print("Email: ");
        String email = sc.nextLine();
        System.out.print("Password: ");
        String password = sc.nextLine();

        Admin admin = model.login(email, password);
        if (admin != null) {
            System.out.println("Admin Login Successful!");
            new AdminHomeView().show();
        } else {
            System.out.println("Invalid credentials");
        }
    }
}