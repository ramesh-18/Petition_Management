package com.cheeks.petit.features.department.selection;

class DepartmentModel {
}
