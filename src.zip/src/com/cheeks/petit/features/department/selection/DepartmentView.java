package com.cheeks.petit.features.department.selection;

public class DepartmentView {
}
