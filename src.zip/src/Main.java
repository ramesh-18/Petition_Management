import com.cheeks.petit.data.repository.DataInitializer;
import com.cheeks.petit.features.MainMenuView;

public class Main {
    public static final int VERSION_NO = 1;
    public static final String VERSION_NAME = "0.0.0";

    public static void main(String[] args) {
        DataInitializer.init();
        new MainMenuView().show();
    }
}